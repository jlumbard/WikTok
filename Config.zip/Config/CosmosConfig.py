import os

settings = {
    'host': os.environ.get('ACCOUNT_HOST', 'https://wiktok.documents.azure.com:443/'),
    'master_key': os.environ.get('ACCOUNT_KEY', 'kxgu5nBVWcXjC6CdgPGDawZMF10T94MmiZXU0RafCqr5oyh9oxvblttEJtdsZzSHh84GYsUuAZ6yxo9aSK3QNg=='),
    'database_id': os.environ.get('COSMOS_DATABASE', 'WikipediaInteractions'),
    'interactions_container_id': os.environ.get('INTERACTIONS_COSMOS_CONTAINER', 'InteractionsV1'),
    'pages_container_id': os.environ.get('PAGES_COSMOS_CONTAINER', 'PagesV1'),
    'users_container_id': os.environ.get('USERS_COSMOS_CONTAINER', 'UsersV1'),
    'userSession_container_id': os.environ.get('USERSESSION_COSMOS_CONTAINER', 'UserSessionV1'),
}