import os

settings = {
    'sqlString': os.environ.get('SQLString', 'mysql+mysqldb://root:M6nkt7hcvcaoBFsk@34.95.12.1/WikTok')
}